const express =require("express");
const User = require("../models/User");
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs");

const router =express.Router();

router.post("/register", async (req,res)=>{
    try {
        const {name, email, password}= req.body;
        const exitingUser =await User.findOne({email});
        if(exitingUser){
            return res.status(400).json({message:"User Earlyday Exist"});
        }

        //create
        const newUser = new User({name, email, password});
        await newUser.save();
        res.status(201).json({message:"User Created Succesfully"}); 

    } catch (error) {
        res.status(500).json({message:error.message})
    }
});

//LogIn
router.post("/login", async (req,res)=>{
    try {
        const {name, email, password}=req.body;

        const existingUser = await User.findOne({email});
        if(!existingUser){
            return res.status(400).json({message:"User Not Found"});
        }

        const isMatch = await bcrypt.compare(password, existingUser.password)
        if(!isMatch){
            return res.status(400).json({message:"Invalid crenditials"});
        }

        //token
        const token =jwt.sign({id: existingUser._id}, process.env.JWT_SECRET, {expiresIn:"1hr"});

        res.json({token, existingUser:{id: existingUser._id, name:existingUser.name, email: existingUser.email}});

    } catch (error) {
        res.status(500).json({message:error.message});
    }
})


module.exports = router;