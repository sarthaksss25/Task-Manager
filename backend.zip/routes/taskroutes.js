const express =require("express");
const Task = require("../models/Task");



const router=express.Router();

//create
router.post("/", async (req,res)=>{
    try {
        const {title, decreption}= req.body;
    const newTask = new Task({title, decreption});
    await newTask.save();
    res.status(201).json(newTask);
        
    } catch (error) {
        res.status(500).json({message:"Server Error"});
    }
});

//getall

router.get("/", async (req,res) =>{
try {
    const allTasks = await Task.find();
    res.status(200).json(allTasks);
    
} catch (error) {
    res.status(500).json({message:"Task Not Found"});
}
});

// updates 

router.put("/:id", async (req,res)=>{
    try {
        const {title, decreption, complated}=req.body;
        const updateTask= await Task.findByIdAndUpdate(
            req.params.id,
            {title, decreption, complated},
            {
                new:true,
            }
        );
        res.status(200).json(updateTask);
    } catch (error) {
        res.status(500).json({message:"Server Error"})
    }
});

//Delete

router.delete("/:id", async(req,res)=>{
    try {
        await Task.findByIdAndDelete(req.params.id);
        res.status(200).json({message:"Task Deleted Successfully"});
    } catch (error) {
        res.status(500).json(error)
        
    }
})

module.exports= router;