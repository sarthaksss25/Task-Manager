const express = require("express");
const dotenv = require("dotenv");
const cors =require("cors");
const mongoose =require("mongoose");
const authRoutes =require("./routes/auth");
const taskRoutes =require("./routes/taskroutes");


dotenv.config();
const app =express();

app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGO_URL)
.then(()=>console.log("MongoDb Connected"))
.catch((err)=>console.log(err));

app.get("/",(req,res)=>{
    res.send("Task Manager api is Running")
});

app.use("/auth",authRoutes);

app.use("/tasks", taskRoutes);

const PORT= process.env.PORT || 5000;
app.listen(PORT, ()=>console.log(`Server Is running on Port ${PORT}`));
