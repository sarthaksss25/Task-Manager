import React from "react";
import { useNavigate } from "react-router-dom";


const Home = () => {
  const navigate =useNavigate();
  const handaleGetStarted =()=>{
      navigate("/register")
  }
  return (
    <>
    <div className="home-container d-flex align-items-center justify-content-center vh-100 text-center">
      <div className="content p-4">
        <h1 >Task Management System</h1>
        <p>
          Organize your tasks efficiently and boost productivity.
        </p>
        <button className="btn btn-sm btn-success px-2" onClick={handaleGetStarted}>Register</button>
        <button className="btn btn-sm ms-3 btn-success px-2" onClick={handaleGetStarted}>Login</button>
      </div>
    </div>
    </>
  );
};

export default Home;
