import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/Authcontext';

const Dashboard = () => {
  const [task, setTask] = useState([]);
  const [editTask, setEditTask] = useState(null);
  const [taskTitle, setTaskTitle] = useState("");
  const { logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchTask();
  }, []);

  const fetchTask = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Not authenticated!");
      navigate("/login");
    }

    try {
      const { data } = await axios.get("http://localhost:5000/tasks", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTask(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleAddOrUpdateTask = async () => {
    const token = localStorage.getItem("token");
    if (!token) return;

    if (!taskTitle.trim()) {
      alert("Task cannot be empty");
      return;
    }

    try {
      if (editTask) {
        await axios.put(
          `http://localhost:5000/tasks/${editTask._id}`,
          { title: taskTitle },
          { headers: { Authorization: `Bearer ${token}` } }
        );

        setTask((prevTasks) =>
          prevTasks.map((t) =>
            t._id === editTask._id ? { ...t, title: taskTitle } : t
          )
        );
      } else {
        const { data } = await axios.post(
          "http://localhost:5000/tasks",
          { title: taskTitle },
          { headers: { Authorization: `Bearer ${token}` } }
        );

        setTask((prevTasks) => [...prevTasks, data]);
      }

      setTaskTitle("");
      setEditTask(null);
    } catch (error) {
      console.error(error);
    }
  };

  const handleEditTask = (task) => {
    setEditTask(task);
    setTaskTitle(task.title);
  };

  const handleDeleteTask = async (taskId) => {
    const token = localStorage.getItem("token");
    if (!token) return;

    try {
      await axios.delete(`http://localhost:5000/tasks/${taskId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTask((prevTasks) => prevTasks.filter((task) => task._id !== taskId));
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Dashboard</h1>
      
      <div className="mb-3 d-flex">
        <input
          type="text"
          className="form-control me-2"
          placeholder="Enter Task Here"
          value={taskTitle}
          onChange={(e) => setTaskTitle(e.target.value)}
        />
        <button className="btn btn-primary" onClick={handleAddOrUpdateTask}>
          {editTask ? "Update" : "Add"}
        </button>
      </div>
      
      <ul className="list-group">
        {task.length === 0 && <p className="text-center">No Tasks Yet Added</p>}
        {task.map((task) => (
          <li key={task._id} className="list-group-item d-flex justify-content-between align-items-center">
            {task.title}
            <div>
              <button className="btn btn-warning btn-sm me-2" onClick={() => handleEditTask(task)}>
                Edit
              </button>
              <button className="btn btn-danger btn-sm" onClick={() => handleDeleteTask(task._id)}>
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
      
      <button className="btn btn-danger mt-4 w-100" onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Dashboard;
