import React, { useRef } from 'react'
import "./Login.css";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/Authcontext';

const Login = () => {
  const {login}= useAuth();
  const navigate= useNavigate();
  const emailRef=useRef(null);
  const passRef =useRef(null);

  const handaleLoginEvent=async(e)=>{
    e.preventDefault();
const loginData ={
  email:emailRef.current.value,
  password:passRef.current.value,
}
try {
  const response = await axios.post("http://localhost:5000/auth/login",loginData);

  if(response.status===200){
     login( response.data.token); // Save token
        alert("Login successfully");
        console.log(response.data.token);
        navigate("/dashboard");
  }

  emailRef.current.value="";
  passRef.current.value="";
  
} catch (error) {
  console.log("Error:", error);
  alert("Invalid email or password. Please try again.");
}

  }
  return (
   <>
   <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4 shadow-lg w-50">
        <h2 className="text-center mb-4">Login</h2>
        <form onSubmit={handaleLoginEvent}>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input type="email" className="form-control" placeholder="Enter your email" ref={emailRef} required />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input type="password" className="form-control" placeholder="Enter your password" ref={passRef} required />
          </div>

          <button type="submit" className="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
   </>
  )
}

export default Login