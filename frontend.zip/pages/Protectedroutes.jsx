import React from 'react'
import { useAuth } from '../context/Authcontext'
import { Navigate } from 'react-router-dom';

const Protectedroutes = ({children}) => {

    const {token} = useAuth();
    return token ? children : <Navigate to={"/login"} />
}

export default Protectedroutes