import React, { useRef, useState } from 'react'
import "./Register.css";
import axios from "axios";
import { Navigate, useNavigate } from 'react-router-dom';

const Register = () => {
  const navigate= useNavigate();
  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const passRef = useRef(null);


  const RegistratonHandle = async (e) => {
    e.preventDefault();
    const userData = {
      name: nameRef.current.value,
      email: emailRef.current.value,
      password: passRef.current.value,
    }

    try {
      const response = await axios.post("http://localhost:5000/auth/register", userData);

      console.log(response);
      console.log(userData);
  
      alert("Registration Succesfull ");
      navigate("/login");
      nameRef.current.value = "";
      emailRef.current.value = "";
      passRef.current.value = "";


    } catch (error) {
      console.error("Error", error);
    }

  }

  return (
    <>
       <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4 shadow-lg w-50">
        <h2 className="text-center mb-4">Registration Form</h2>
        <form onSubmit={RegistratonHandle}>
          <div className="mb-3">
            <label className="form-label">Name:</label>
            <input type="text" className="form-control" ref={nameRef} required />
          </div>

          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input type="email" className="form-control" ref={emailRef} required />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input type="password" className="form-control" ref={passRef} required />
          </div>

          <button type="submit" className="btn btn-primary w-100">Register</button>
        </form>
      </div>
    </div>


    </>
  )
}

export default Register